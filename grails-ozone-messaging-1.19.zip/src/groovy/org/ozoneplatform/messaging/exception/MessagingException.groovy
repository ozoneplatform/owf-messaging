package org.ozoneplatform.messaging.exception

class MessagingException extends RuntimeException{

    public MessagingException(String message, Throwable cause) {
        super(message, cause);
    }
    
}
